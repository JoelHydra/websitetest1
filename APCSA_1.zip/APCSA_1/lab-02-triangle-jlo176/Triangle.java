public class Triangle{
  // Instance Variables
  private Point v1;
  private Point v2;
  private Point v3;

  // Constructors
  public Triangle(double x1, double y1, double x2, double y2, double x3, double y3)
  {
    v1 = new Point(x1, y1);
    v2 = new Point(x2, y2);
    v3 = new Point(x3, y3);
  }

  public Triangle(Point v1, Point v2, Point v3)
  {
    this.v1 = v1;
    this.v2 = v2;
    this.v3 = v3;
  }

  // Methods
  public Point getVertex(int v) //assumes v is either 1, 2, or 3
  {
    if (v == 1)
    {
      return v1;
    }
    else if (v == 2)
    {
      return v2;
    }
    return v3;
  }

  public void setVertex(int v, Point p) //assumes v is either 1, 2, or 3
  {
    if (v == 1)
    {
      v1 = p;
    }
    else if (v == 2)
    {
      v2 = p;
    }
    else
    {
      v3 = p;
    }
  }

  public String toString()
  {
    return "{" + v1 + ", " + v2 + ", " + v3 + "}";
  }

  public double getPerimeter()
  {
    return Point.distance(v1, v2) + Point.distance(v2, v3) + Point.distance (v3, v1);
  }

  public boolean equals(Triangle other){
    return (this.v1.isEqual(other.getVertex(1)) && this.v2.isEqual(other.getVertex(2)) && this.v3.isEqual(other.getVertex(3)));
  }

  public String getTriangleType(){
    if (v1.distanceTo(v2) == v2.distanceTo(v3) && v1.distanceTo(v2) == v1.distanceTo(v3))
    {
      return "equilateral";
    }
    if (v1.distanceTo(v2) == v2.distanceTo(v3) || v2.distanceTo(v3) == v3.distanceTo(v1) || v3.distanceTo(v1) == v1.distanceTo(v2))
    {
      return "isosceles";
    }
    return "scalene";
  }

  public double getArea(){
    double a = v1.distanceTo(v2);
    double b = v2.distanceTo(v3);
    double c = v3.distanceTo(v1);
    double s = (a + b + c) / 2;
    return Math.sqrt(s * (s - a) * (s - b) * (s - c));
  }
}
