public class Driver{
  public static void main(String[]args){
    /* Write your tests here
    * Make sure to write more than 3 test cases
    * Three or less test cases will lower your grade
    * When your create tests cases try to test extreme cases (something that is not commmon, but it could happen)
    * When your create tests cases, you should test all the methods you coded in your class Poimt
    */ 

    /*****************     TEST CASE 00    ******************/
    
    Point p1 = new Point(8.0, 8.0);
    Point p2 = new Point(2.0, 10.0);
    Point p3 = new Point(0.0, 0.0);

    // Print coordinates using your toString method from Point class
    System.out.println("p1: " + p1);
    System.out.println("p2: " + p2);
    System.out.println("p3: " + p3);
    
    // Calculate distances and print results
    System.out.println("distance1: " + Point.distance(p1, p2));
    System.out.println("distance2: " + Point.distance(p2, p3));
    System.out.println("distance3: " + Point.distance(p3, p1));

    // Create Triangle objects and test the methods
    Triangle tri = new Triangle(p1, p2, p3);
    Triangle tri2 = new Triangle(p1, p2, p3);

    System.out.println("Triangle:" + tri);

    System.out.println("perimeter: " + tri.getPerimeter());

    System.out.println("v1: " + tri.getVertex(1));
    System.out.println("v2: " + tri.getVertex(2));
    System.out.println("v3: " + tri.getVertex(3));
    tri.setVertex(1, new Point(5, 5));
    System.out.println("new v1: " + tri.getVertex(1));

    System.out.println("is equal?: " + tri.equals(tri2));

    System.out.println("triangle type: " + tri.getTriangleType());

    System.out.println("area: " + tri.getArea());

    System.out.println("new perimeter: " + tri.getPerimeter());
  
    /*************     TEST CASE 01    *************/

    System.out.println();

    p1 = new Point(-10.0, -4.0);
    p2 = new Point(12.0, 0.0);
    p3 = new Point(-10.0, 4.0);

    System.out.println("p1: " + p1);
    System.out.println("p2: " + p2);
    System.out.println("p3: " + p3);
    
    System.out.println("distance1: " + Point.distance(p1, p2));
    System.out.println("distance2: " + Point.distance(p2, p3));
    System.out.println("distance3: " + Point.distance(p3, p1));

    tri = new Triangle(p1, p2, p3);
    tri2 = new Triangle(p1, p2, new Point(-9.99, 4.0));

    System.out.println("Triangle:" + tri);

    System.out.println("perimeter: " + tri.getPerimeter());

    System.out.println("v1: " + tri.getVertex(1));
    System.out.println("v2: " + tri.getVertex(2));
    System.out.println("v3: " + tri.getVertex(3));
    tri.setVertex(2, new Point(5.0, 0.0));
    System.out.println("new v2: " + tri.getVertex(2));

    System.out.println("is equal?: " + tri.equals(tri2));

    System.out.println("triangle type: " + tri.getTriangleType());

    System.out.println("area: " + tri.getArea());

    System.out.println("new perimeter: " + tri.getPerimeter());

    /*************     TEST CASE 02    *************/

    System.out.println();

    p1 = new Point(0.0, .0001);
    p2 = new Point(0.0, 0.0);
    p3 = new Point(0.0, .0002);

    System.out.println("p1: " + p1);
    System.out.println("p2: " + p2);
    System.out.println("p3: " + p3);
    
    System.out.println("distance1: " + Point.distance(p1, p2));
    System.out.println("distance2: " + Point.distance(p2, p3));
    System.out.println("distance3: " + Point.distance(p3, p1));

    tri = new Triangle(p1, p2, p3);
    tri2 = new Triangle(p1, p2, p3);

    System.out.println("Triangle:" + tri);

    System.out.println("perimeter: " + tri.getPerimeter());

    System.out.println("v1: " + tri.getVertex(1));
    System.out.println("v2: " + tri.getVertex(2));
    System.out.println("v3: " + tri.getVertex(3));
    tri.setVertex(3, new Point(0.001, 0.0));
    System.out.println("new v3: " + tri.getVertex(3));

    System.out.println("is equal?: " + tri.equals(tri2));

    System.out.println("triangle type: " + tri.getTriangleType());

    System.out.println("area: " + tri.getArea());

    System.out.println("new perimeter: " + tri.getPerimeter());

   /*************     TEST CASE 03    *************/

   System.out.println();

    p1 = new Point(0.0, 0.0);
    p2 = new Point(0.0, 1.0);
    p3 = new Point(1.0, 0.0);

    System.out.println("p1: " + p1);
    System.out.println("p2: " + p2);
    System.out.println("p3: " + p3);
    
    System.out.println("distance1: " + Point.distance(p1, p2));
    System.out.println("distance2: " + Point.distance(p2, p3));
    System.out.println("distance3: " + Point.distance(p3, p1));

    tri = new Triangle(p1, p2, p3);
    tri2 = new Triangle(p1, p2, new Point(10.0,10.0));

    System.out.println("Triangle:" + tri);

    System.out.println("perimeter: " + tri.getPerimeter());

    System.out.println("v1: " + tri.getVertex(1));
    System.out.println("v2: " + tri.getVertex(2));
    System.out.println("v3: " + tri.getVertex(3));
    tri.setVertex(3, new Point(0.5,0.5));
    System.out.println("new v3: " + tri.getVertex(3));

    System.out.println("is equal?: " + tri.equals(tri2));

    System.out.println("triangle type: " + tri.getTriangleType());

    System.out.println("area: " + tri.getArea());

    System.out.println("new perimeter: " + tri.getPerimeter());
  }
}
