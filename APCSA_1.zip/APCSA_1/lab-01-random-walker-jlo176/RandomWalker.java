import java.util.Scanner;

public class RandomWalker
{
  public static void nStepsDistance(int n)
  {
    //create direction and pos as int and array and print starting pos
	  int direction = 0;
    int[] pos = {0,0};
    System.out.println("(0,0)");
    //loop n times for each step
	  while (n > 0)
	  {
      //50% chance each for moving backwards or forwards
  	  if (Math.random() < .5)
  	  {
    	  direction = 1;
  	  }
      else
    	{
      	direction = -1;
    	}
      //50% chance each for moving along x or y axis, overall 25% chance for each direction
      if (Math.random() < .5)
      {
        pos[0] += direction;
      }
      else
      {
        pos[1] += direction;
      }
      //print pos and increment n
      System.out.println("(" + pos[0] + "," + pos[1] + ")");
      n--;
	  }
    //print square distance
    System.out.println(Math.pow(pos[0],2) + Math.pow(pos[1],2));
  }

  public static void main(String[] args)
  {
    //make input variable and set it to user input
    Scanner input = new Scanner(System.in);
    System.out.println("How many steps?");
    int steps = input.nextInt();
    input.nextLine();
    //run the method for the inputted amount of steps
    nStepsDistance(steps);
  }
}
