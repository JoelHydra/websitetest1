public class ArrayMethods
{
    public static void main(String[] args)
    {
      print(new int[][] {{1,2,3},{4,5,6}});
      print(new int[][] {{1,2,3}});
      print(new int[][] {{1,2,3},{4,5},{6}});
      print(new int[][] {{},{},{}});

      System.out.println(findSum(new int[][] {{1,1,1},{1,1,1}}));
      System.out.println(findSum(new int[][] {{1,2,3,4}}));
      System.out.println(findSum(new int[][] {{1,2,3},{4,5},{6}}));
      System.out.println(findSum(new int[][] {{},{},{}}));

      print(transpose(new int[][] {{1,2,3},{1,2,3},{1,2,3}}));
      print(transpose(new int[][] {{1,2,3}}));
      print(transpose(new int[][] {{1,2,3,4},{5,6,7,8}}));
      print(transpose(new int[][] {{},{},{}}));
    }
    
    public static void print(int[][] array){
        String arrayString = "[";
        for (int row = 0; row < array.length; row++)
        {
            if (row != 0)
            {
                arrayString += ", ";
            }
            arrayString += "[";
            for (int col = 0; col < array[row].length; col++)
            {
                if (col != 0)
                {
                    arrayString += ", ";
                }
                arrayString += "" + array[row][col];
            }
            arrayString += "]";
        }
        arrayString += "]";
        System.out.println(arrayString);
    }
  
    public static int findSum(int[][] array){
        int sum = 0;
        for (int[] subArray : array)
        {
            for (int element : subArray)
            {
                sum += element;
            }
        }
        return sum;
    }
        

    public static int[][] transpose(int[][] array){
        int[][] transposed = new int[array[0].length][array.length];
        for (int row = 0; row < array[0].length; row++)
        {
            for (int col = 0; col < array.length; col++)
            {
                transposed[row][col] = array[col][row];
            }
        }
        return transposed;
    } 
}