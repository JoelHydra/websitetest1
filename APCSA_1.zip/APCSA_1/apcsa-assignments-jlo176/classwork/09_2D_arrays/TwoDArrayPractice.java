public class TwoDArrayPractice
{

  public static void main(String[] args)
    {
      // Create test cases here.
      
      // Print the status of your 2D array before and after
      // invoking a method. You will need to add a print() method
      // to avoid duplicated code in your main.

      int[][] testArray0 = new int[][] {{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}};
      rowSwap(testArray0,1,2);
      print(testArray0);

      int[][] testArray1 = new int[][] {{0,0,0},{1,1,1},{2,2,2}};
      rowSwap(testArray1,0,2);
      print(testArray1);


      int[][] testArray2 = new int[][] {{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}};
      colSwap(testArray2,2,4);
      print(testArray2);

      int[][] testArray3 = new int[][] {{2,4,6,8},{3,6,9,12},{4,8,12,16},{5,10,15,20}};
      colSwap(testArray3,0,2);
      print(testArray3);


      print2(fillRows("hellooooo", 3, 5));

      print2(fillRows("aoaoaoaoaoaoaoaoaoaoaoao", 5, 4));
    }

    //print array method
    public static void print(int[][] array)
    {
        String arrayString = "[";
        for (int row = 0; row < array.length; row++)
        {
            if (row != 0)
            {
                arrayString += ", ";
            }
            arrayString += "[";
            for (int col = 0; col < array[row].length; col++)
            {
                if (col != 0)
                {
                    arrayString += ", ";
                }
                arrayString += "" + array[row][col];
            }
            arrayString += "]";
        }
        arrayString += "]";
        System.out.println(arrayString);
    }

    //same but with string[][] input
    public static void print2(String[][] array)
    {
        String arrayString = "[";
        for (int row = 0; row < array.length; row++)
        {
            if (row != 0)
            {
                arrayString += ", ";
            }
            arrayString += "[";
            for (int col = 0; col < array[row].length; col++)
            {
                if (col != 0)
                {
                    arrayString += ", ";
                }
                arrayString += "" + array[row][col];
            }
            arrayString += "]";
        }
        arrayString += "]";
        System.out.println(arrayString);
    }

  
    /*
     * Swaps all values in the specified 2 rows of array.
    */
  public static void rowSwap(int[][] array, int rowAIndex, int rowBIndex)
    {
        //assumes non-ragged array
        int rowAElement;
        int rowBElement;
        for (int col = 0; col < array[0].length; col++)
        {
            rowBElement = array[rowBIndex][col];
            rowAElement = array[rowAIndex][col];
            array[rowAIndex][col] = rowBElement;
            array[rowBIndex][col] = rowAElement;
        }
    }

  
    /**
     * Swaps all values in the specified 2 columns of array.
     */
    public static void colSwap(int[][] array, int colAIndex, int colBIndex)
    {
        //assumes non-ragged array
        int colAElement;
        int colBElement;
        for (int row = 0; row < array.length; row++)
        {
            colAElement = array[row][colAIndex];
            colBElement = array[row][colBIndex];
            array[row][colAIndex] = colBElement;
            array[row][colBIndex] = colAElement;
        }
    }

  
    /*
     * Returns an array with the specified number of rows and columns
     * containing the characters from str in row-major order. If str.length()
     * is greater than rows * cols, extra characters are ignored. If
     * str.length() is less than rows * cols, the remaining elements in the
     * returned array contain null.

     Examples:

      String[][] result = fillRows("Happy Halloween", 3, 4);
      
      result (after method call):
      "H"     "a"     "p"     "p"
      "y"     " "     "H"     "a"
      "l"     "l"     "o"     "w"
      
      
      String[][] result = fillRows("hello", 3, 4);
      
      result (after method call):
      "h"     "e"     "l"     "l"
      "o"     null    null    null
      null    null    null    null

     */
    public static String[][] fillRows(String str, int rows, int cols)
    {
        String[][] array = new String[rows][cols];
        for (int row = 0; row < rows; row++)
        {
            for (int col = 0; col < cols; col++)
            {
                if (row * cols + col + 1 <= str.length())
                {
                    array[row][col] = str.substring(row * cols + col, row * cols + col + 1);
                }
                else
                {
                    break;
                }
            }
        }
        return array;
    }
  
}    