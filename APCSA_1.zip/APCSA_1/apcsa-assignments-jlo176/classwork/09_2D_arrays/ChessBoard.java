public class ChessBoard
{
    public static void main(String[] args)
    {
        //Create an 8x8 2D String array called chess.
        String[][] chess = new String[8][8];
        for (int row = 0; row < 8; row++)
        {
            for (int col = 0; col < 8; col++)
            {
                if (row == 1 || row == 6)
                {
                    chess[row][col] = "Pawn";
                }
                else if ((row == 0 || row == 7) && (col == 0 || col == 7))
                {
                    chess[row][col] = "Rook";
                }
                else if ((row == 0 || row == 7) && (col == 1 || col == 6))
                {
                    chess[row][col] = "Knight";
                }
                else if ((row == 0 || row == 7) && (col == 2 || col == 5))
                {
                    chess[row][col] = "Bishop";
                }
                else if ((row == 0 || row == 7) && col == 3)
                {
                    chess[row][col] = "Queen";
                }
                else if ((row == 0 || row == 7) && col == 4)
                {
                    chess[row][col] = "King";
                }
                else
                {
                    chess[row][col] = "-";
                }
            }
        }
        
        //Use this method to print the chess board onto the console
        print(chess);
    }
    
    public static void print(String[][] array)
    {
        String arrayString = "[";
        for (int row = 0; row < array.length; row++)
        {
            if (row != 0)
            {
                arrayString += ", ";
            }
            arrayString += "[";
            for (int col = 0; col < array[row].length; col++)
            {
                if (col != 0)
                {
                    arrayString += ", ";
                }
                arrayString += "" + array[row][col];
            }
            arrayString += "]";
        }
        arrayString += "]";
        System.out.println(arrayString);
    }
}