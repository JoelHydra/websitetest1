public class Point
{
  private double xcor;
  private double ycor;

  public Point()
  {

  }

  public Point(double x, double y)
  {
    xcor = x;
    ycor = y;
  }
}
