public class SuperArray{
  private String[] data;
  private int size = 0;

  public SuperArray(){
    data = new String[10];
  }

  public SuperArray(int initialCapacity){
    data = new String[initialCapacity];
  }

  public int size(){
    return size;
  }

  public boolean add(String value){
      if (size < data.length)
      {
        data[size] = value;
        size++;
        return true;
      }
      this.resize();
      data[size] = value;
      size++;
      return false;
  }

  public String toString(){
    String str = "[";
    for (int i = 0; i < size; i++)
    {
      str += data[i];
      if (i < size - 1)
      {
        str += ", ";
      }
    }
    str += "]";
    return str;
  }

  public String get(int index){
    if (index < 0 || index >= size)
    {
      System.out.println("index invalid");
      return null;
    }
    return data[index];
  }

  public String set(int index, String newValue){
    if (index < 0 || index >= size)
    {
      System.out.println("index invalid");
      return null;
    }
    String temp = data[index];
    data[index] = newValue;
    return temp;
  }

  public String remove(int index){
    if (index < 0 || index >= size)
    {
      System.out.println("index invalid");
      return null;
    }
    String temp = data[index];
    for (int i = index; i < size; i++)
    {
      if (i != size)
      {
        data[i] = data[i + 1];
      }
      else
      {
        data[i] = null;
      }
    }
    size--;
    return temp;
  }

  public boolean remove(String target){
    for (int i = 0; i < size; i++)
    {
      if (target.equals(data[i]))
      {
        this.remove(i);
        return true;
      }
    }
    return false;
  }

  private void resize(){
    String[] newArray = new String[2 * data.length + 1];
    for (int i = 0; i < size; i++)
    {
      newArray[i] = data[i];
    }
    data = newArray;
  }

  public int indexOf(String target)
  {
    for (int i = 0; i < size; i++)
    {
      if (target.equals(data[i]))
      {
        return i;
      }
    }
    return -1;
  }

  public int lastIndexOf(String target){
    for (int i = size - 1; i >= 0; i--)
    {
      if (target.equals(data[i]))
      {
        return i;
      }
    }
    return -1;
  }
}
