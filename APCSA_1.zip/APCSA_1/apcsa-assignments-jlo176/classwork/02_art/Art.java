public class Art{
    public static void main(String[] args){
        System.out.println("     /\\  _");
        System.out.println("    /  \\| |");
        System.out.println("   /    \\ |");
        System.out.println("  /      \\|");
        System.out.println(" /________\\");
        System.out.println(" |        |");
        System.out.println(" |   __   |");
        System.out.println(" |  | .|  |");
        System.out.println(" |__|__|__|");
    }
}