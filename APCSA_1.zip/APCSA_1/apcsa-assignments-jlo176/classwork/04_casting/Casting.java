public class Casting
{
    public static void intDivision(int a, int b)
    {
        System.out.println((double)a / b);
    }
    public static void main(String[] args)
    {
        intDivision(3,4);
    }
}