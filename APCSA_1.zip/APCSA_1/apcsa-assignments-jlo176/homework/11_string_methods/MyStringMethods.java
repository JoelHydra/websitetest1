public class MyStringMethods{

    // indexof takes some character or string and outputs the index of the first occurence of the character/string.
    // if the target is not in the string, it returns -1
    public static int myIndexOf(String myString, String targetString){
        //skips loop if target is shorter than mystring
        //else returns the index that makes the target equal to the substring at index i
        for (int i = 0; i <= myString.length() - targetString.length(); i++)
        {
            if (myString.substring(i, i + targetString.length()).equals(targetString))
            {
                 return i;
            }
         }
        return -1;
    }                             
  
    // compare to returns 0 if the strings are the same
    // returns difference of length or difference of unicode number of the first differing character
    public static int myCompareTo(String myString, String otherString){
      //0 if equal
      if (myString.equals(otherString))
      {
        return 0;
      }
      //if a character isn't matched returns unicode difference
      for (int i = 0; i < Math.min(myString.length(), otherString.length()); i++)
      {
        if (myString.charAt(i) != otherString.charAt(i))
        {
            return (int)myString.charAt(i) - (int)otherString.charAt(i);
        }
      }
      //otherwise returns length difference
      return myString.length() - otherString.length();
    }
  
    // parseint takes a string of numbers and returns it as an integer
   public static int myparseInt(String myString){
      //check for negatives
      boolean negative = false;
      if (myString.charAt(0) == '-')
      {
        myString = myString.substring(1, myString.length());
        negative = true;
      }
      int guess = 0;
      //go through each character and add 1 to each digit until it matches the character
      for (int i = 0; i < myString.length(); i++)
      {
        for (int n = 0; !myString.substring(i, i + 1).equals("" + n); n++)
        {
            guess += Math.pow(10, myString.length() - (i + 1));
        }
      }
      //negates guess if negative
      if (negative)
      {
        guess *= -1;
      }
      return guess;
   }

}