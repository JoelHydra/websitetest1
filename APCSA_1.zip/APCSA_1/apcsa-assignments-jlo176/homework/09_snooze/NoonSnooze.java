import java.util.Scanner;

public class NoonSnooze {
    public static void main(String[] args)
    {
        Scanner input = new Scanner (System.in);

        System.out.println("How many minutes past noon is it?");
        int min = input.nextInt();

        int hr = min / 60;
        
        //am or pm check
        String halfDay;
        if (hr / 12 % 2 == 0)
        {
            halfDay = " pm";
        }
        else
        {
            halfDay = " am";
        }
        
        //print output
        String output;
        //add 0 if min has less than 2 digits
        if (min % 60 < 10)
        {
            output = (hr - 1) % 12 + 1 + ":0" + min % 60 + halfDay;
        }
        else
        {
            output = (hr - 1) % 12 + 1 + ":" + min % 60 + halfDay;
        }

        if (min < 0)
        {
            System.out.println("No negative values are allowed");
        }
        else
        {
            System.out.println(output);
        }
    }
}
