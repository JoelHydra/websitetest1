public class Employee
{
    private int salary;
    private int hours;
    private String position;

    //constructors
    public Employee()
    {

    }

    public Employee(String pos)
    {
        position = pos;
    }

    public Employee(String pos, int pay, int hrs)
    {
        position = pos;
        salary = pay;
        hours = hrs;
    }

    //methods (getters and setters)
    public String getPosition()
    {
        return position;
    }

    public int getSalary()
    {
        return salary;
    }

    public int getHours()
    {
        return hours;
    }

    public void changePosition(String pos)
    {
        position = pos;
    }

    //static method
    public static void msg()
    {
        System.out.println("Is employed");
    }

    public void nonStatic()
    {
      msg();
    }

    public static void static()
    {
      getSalary();
    }

    /* you can call a static method from a non-static one but not vice versa */
}
