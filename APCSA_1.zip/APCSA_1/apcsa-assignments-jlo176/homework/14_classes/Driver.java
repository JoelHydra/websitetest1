public class Driver {
    public static void main(String[] args)
    {
        Employee bob = new Employee();
        Employee amy = new Employee("accountant");
        Employee alex = new Employee("manager",80000,40);

        System.out.println(amy.getPosition());
        System.out.println(alex.getSalary());
        System.out.println(bob.getHours());

        System.out.println(bob.getPosition());
        bob.changePosition("consultant");
        System.out.println(bob.getPosition());

        Employee.msg();
    }
}
