public class MyArrayPractice
{
    public static void main(String[] args)
    {
        int[][] test1 = {{1,2,3},{3,2,1}};
        int[][] copyTest1 = copy(test1);
        copyTest1[0][0] = 10;
        print(copyTest1);
        print(test1);

        int[][] test2 = {{1,1,1},{2,2},{3}};
        int[][] copyTest2 = copy(test2);
        copyTest2[1][1] = 5;
        print(copyTest2);
        print(test2);


        int[][] test3 = {{-1,-2,-3},{-4,-5,-6},{-7,-8,-9}};
        print(updateValues(test3));

        int[][] test4 = {{-3,2,1},{5,4,3,-2,-1},{3,2,-1}};
        print(updateValues(test4));
    }

    public static int[][] copy(int[][] nums)
    {
        int[][] copy = new int[nums.length][];
        for (int row = 0; row < nums.length; row++)
        {
            copy[row] = new int[nums[row].length];
            for (int col = 0; col < nums[row].length; col++)
            {
                copy[row][col] = nums[row][col];
            }
        }
        return copy;
    }

    public static int[][] updateValues(int[][] nums)
    {
        int[][] updated = new int[nums.length][];
        for (int row = 0; row < nums.length; row++)
        {
            updated[row] = new int[nums[row].length];
            for (int col = 0; col < nums[row].length; col++)
            {
                if (nums[row][col] >= 0)
                {
                    updated[row][col] = nums[row][col];
                }
                else if (row == col)
                {
                    updated[row][col] = 0;
                }
                else
                {
                    updated[row][col] = 1;
                }
            }
        }
        return updated;
    }

    //print int[][]
    public static void print(int[][] array)
    {
        String arrayString = "[";
        for (int row = 0; row < array.length; row++)
        {
            if (row != 0)
            {
                arrayString += ", ";
            }
            arrayString += "[";
            for (int col = 0; col < array[row].length; col++)
            {
                if (col != 0)
                {
                    arrayString += ", ";
                }
                arrayString += "" + array[row][col];
            }
            arrayString += "]";
        }
        arrayString += "]";
        System.out.println(arrayString);
    }
}