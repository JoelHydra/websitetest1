public class Calculator {
    public static void sum(int a, int b){
        System.out.print(a + " + " + b + " = " + (a + b));
    }
    public static void main(String[] args){
        sum(10,12);
    }
}
