public class Temperature{
    public static void TemperatureConvert(double F){
        double C = (F - 32) / 1.8;
        System.out.print(F + " degrees Fahrenheit is equal to " + C + " Celsius");
    }
    public static void main(String[] args){
        TemperatureConvert(50.0);
    }
}
