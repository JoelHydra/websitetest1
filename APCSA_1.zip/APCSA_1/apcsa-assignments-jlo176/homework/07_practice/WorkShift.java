public class WorkShift{
    public static void timeInSeconds(int hr, int min, int s){
        int totalSeconds = (hr * 3600) + (min * 60) + s;
        // why do we need compund operators???
        totalSeconds += 0;
        System.out.print("Total shift time in seconds is " + totalSeconds);
    }
    public static void main(String[] args){
        timeInSeconds(20,42,16);
    }
}
