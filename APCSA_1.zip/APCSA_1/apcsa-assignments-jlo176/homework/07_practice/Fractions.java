public class Fractions{
    public static void fractionSum(int num1, int den1, int num2, int den2){
        String sum = (num1 * den2 + num2 * den1) + "/" + (den1 * den2);
        System.out.println("The numerator of the first fraction is " + num1);
        System.out.println("The denominator of the first fraction is " + den1);
        System.out.println("The numerator of the second fraction is " + num2);
        System.out.println("The denominator of the second fraction is " + den2);
        System.out.println("The sum of " + num1 + "/" + den1 + " + " + num2 + "/" + den2 + " = " + sum);
    }
    public static void main(String[] args){
        fractionSum(1,2,2,5);
    }
}
